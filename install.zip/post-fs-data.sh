
mount -o bind $MODPATH/system/vendor/odm/etc/gps.conf /odm/etc/gps.conf
mount -o bind $MODPATH/system/vendor/odm/etc/gps_debug.conf /odm/etc/gps_debug.conf

mount -o bind $MODPATH/system/my_product/etc/gps.conf /my_product/etc/gps.conf
mount -o bind $MODPATH/system/my_product/etc/gps_debug.conf /my_product/etc/gps_debug.conf
