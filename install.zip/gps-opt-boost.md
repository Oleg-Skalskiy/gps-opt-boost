### GPS Boost&Opt v1.0 - 23.09.2023

* Improved GPS stability Fixed
  * Fix Server to Select
  * Add New Parametrs for Speed & Stability
  * Emergency Location ON
  * Minor fixes
  * Fix Code
