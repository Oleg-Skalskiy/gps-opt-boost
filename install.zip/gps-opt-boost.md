### GPS Boost&Opt v1.0 - 09.05.2022

* Improved GPS stability Fixed
  * Log OFF
  * Fix Server to Select
  * Emergency Location ON
  * Minor fixes
