
umount -f /odm/etc/gps.conf
umount -f /odm/etc/gps_debug.conf

umount -f /my_product/etc/gps.conf
umount -f /my_product/etc/gps_debug.conf

GPSCFG="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "gps*.conf")"
mkdir -p $MODPATH/tools
cp -f $MODPATH/common/addon/External-Tools/tools/$ARCH32/* $MODPATH/tools/

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$GCFG $CFG
	cp_ch /odm/etc/gps.conf $MODPATH/system/vendor/odm/etc/gps.conf
	cp_ch /odm/etc/gps_debug.conf $MODPATH/system/vendor/odm/etc/gps_debug.conf
	cp_ch /my_product/etc/gps.conf $MODPATH/system/my_product/etc/gps.conf
	cp_ch /my_product/etc/gps_debug.conf $MODPATH/system/my_product/etc/gps_debug.conf
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG
	sed -i 's/NTRIP_CLIENT_LIB_NAME/#NTRIP_CLIENT_LIB_NAME/g' $CFG
	sed -i 's/PROXY_APP_PACKAGE_NAME/#PROXY_APP_PACKAGE_NAME/g' $CFG
	sed -i 's/DEBUG_LEVEL = 1/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 2/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 3/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 4/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 5/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL=1/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL=2/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL=3/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL=4/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL=5/DEBUG_LEVEL = 0/g' $CFG
	sed -i '/QXDM_LOG/d;s/^DEBUG_LEVEL = 0$/QXDM_LOG = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/BUFFER_DIAG_LOGGING/d;s/^DEBUG_LEVEL = 0$/BUFFER_DIAG_LOGGING = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/LOG_BUFFER_ENABLED/d;s/^DEBUG_LEVEL = 0$/LOG_BUFFER_ENABLED = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/CID_DEFAULT_PROFILE/d;s/^DEBUG_LEVEL = 0$/CID_DEFAULT_PROFILE = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/SUPL_ES/d;s/^DEBUG_LEVEL = 0$/SUPL_ES=1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/USE_EMERGENCY_PDN_FOR_EMERGENCY_SUPL/d;s/^DEBUG_LEVEL = 0$/USE_EMERGENCY_PDN_FOR_EMERGENCY_SUPL=1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/CP_MTLR_ES/d;s/^DEBUG_LEVEL = 0$/CP_MTLR_ES=1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/AGPS_CONFIG_INJECT/d;s/^DEBUG_LEVEL = 0$/AGPS_CONFIG_INJECT = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/ENABLE_PSDS_PERIODIC_DOWNLOAD/d;s/^DEBUG_LEVEL = 0$/ENABLE_PSDS_PERIODIC_DOWNLOAD=true\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/POSITION_ASSISTED_CLOCK_ESTIMATOR_ENABLED/d;s/^DEBUG_LEVEL = 0$/POSITION_ASSISTED_CLOCK_ESTIMATOR_ENABLED = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/SUPL_HOST/d;s/^DEBUG_LEVEL = 0$/SUPL_HOST=supl.qxwz.com\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/SUPL_PORT/d;s/^DEBUG_LEVEL = 0$/SUPL_PORT=7275\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/MO_SUPL_HOST/d;s/^DEBUG_LEVEL = 0$/MO_SUPL_HOST=supl.qxwz.com\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/MO_SUPL_PORT/d;s/^DEBUG_LEVEL = 0$/MO_SUPL_PORT=7275\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/SET_ROAMING/d;s/^DEBUG_LEVEL = 0$/SET_ROAMING = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/XTRA_TEST_ENABLED/d;s/^DEBUG_LEVEL = 0$/XTRA_TEST_ENABLED = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/XTRA_VERSION_CHECK/d;s/^DEBUG_LEVEL = 0$/XTRA_VERSION_CHECK = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/XTRA_THROTTLE_ENABLED/d;s/^DEBUG_LEVEL = 0$/XTRA_THROTTLE_ENABLED = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/XTRA_SYSTEM_TIME_INJECT/d;s/^DEBUG_LEVEL = 0$/XTRA_SYSTEM_TIME_INJECT = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/XTRA_SOCK_KEEPALIVE/d;s/^DEBUG_LEVEL = 0$/XTRA_SOCK_KEEPALIVE = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NMEA_PROVIDER/d;s/^DEBUG_LEVEL = 0$/NMEA_PROVIDER=1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/ENABLE_WIPER/d;s/^DEBUG_LEVEL = 0$/ENABLE_WIPER=1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/DEFAULT_AGPS_ENABLE/d;s/^DEBUG_LEVEL = 0$/DEFAULT_AGPS_ENABLE=true\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/DEFAULT_USER_PLANE/d;s/^DEBUG_LEVEL = 0$/DEFAULT_USER_PLANE=true\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/ACCURACY_THRES/d;s/^DEBUG_LEVEL = 0$/ACCURACY_THRES=0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/DR_SYNC_ENABLED/d;s/^DEBUG_LEVEL = 0$/DR_SYNC_ENABLED = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/SUPL_MODE/d;s/^DEBUG_LEVEL = 0$/SUPL_MODE=0xF\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/CAPABILITIES/d;s/^DEBUG_LEVEL = 0$/CAPABILITIES=0xFF\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG
	sed -i '/NTP_SERVER/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=ru.pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_2=europe.pool.ntp.org\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_3=0.ru.pool.ntp.org\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_4=1.ru.pool.ntp.org\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_5=2.ru.pool.ntp.org\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_6=3.ru.pool.ntp.org\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_7/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_7=ntp0.ntp-servers.net\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_8/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_8=ntp1.ntp-servers.net\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_9/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_9=ntp2.ntp-servers.net\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_10/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_10=ntp3.ntp-servers.net\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_11/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_11=ntp4.ntp-servers.net\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_12/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_12=ntp5.ntp-servers.net\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_13/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_13=ntp6.ntp-servers.net\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_14/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_14=ntp7.ntp-servers.net\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_15/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_15=ntp.ix.ru\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=europe.pool.ntp.org$/NTP_SERVER=time.xtracloud.net\nNTP_SERVER_2=europe.pool.ntp.org/g' $CFG
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done
ui_print " "
ui_print "***************************************************"
ui_print "***************************************************"
ui_print "*  The NTP Server Russia is selected by default   *"
ui_print "*  Would you like to choose a different server?   *"
ui_print "***************************************************"
ui_print "* [Vol Up = YES          |         Vol Down = NO] *"
ui_print "***************************************************"

if $VKSEL; then

ui_print "***************************************************"
ui_print "*              You live in Africa?                *"
ui_print "***************************************************"
ui_print "* [Vol Up = YES          |         Vol Down = NO] *"
ui_print "***************************************************"

if $VKSEL; then

ui_print "*           ->[Select Africa Region]<-            *"
ui_print "***************************************************"

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG
	sed -i '/NTP_SERVER/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=africa.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=0.africa.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=1.africa.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_5=2.africa.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_6=3.africa.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=africa.pool.ntp.org$/NTP_SERVER=time.xtracloud.net\nNTP_SERVER_2=africa.pool.ntp.org/g' $CFG
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done
fi

ui_print "***************************************************"
ui_print "*               You live in Asia?                 *"
ui_print "***************************************************"
ui_print "* [Vol Up = YES          |         Vol Down = NO] *"
ui_print "***************************************************"

if $VKSEL; then

ui_print "*           ->[[Select Asia Region]<-             *"
ui_print "***************************************************"

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG
	sed -i '/NTP_SERVER/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=asia.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=0.asia.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=1.asia.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_5=2.asia.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_6=3.ru.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=asia.pool.ntp.org$/NTP_SERVER=time.xtracloud.net\nNTP_SERVER_2=asia.pool.ntp.org/g' $CFG
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done
fi

ui_print "***************************************************"
ui_print "*              You live in Europe?                *"
ui_print "***************************************************"
ui_print "* [Vol Up = YES          |         Vol Down = NO] *"
ui_print "***************************************************"

if $VKSEL; then

ui_print "*           ->[Select Europe Region]<-            *"
ui_print "***************************************************"

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG
	sed -i '/NTP_SERVER/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=europe.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=0.europe.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=1.europe.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_5=2.europe.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_6=3.europe.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=europe.pool.ntp.org$/NTP_SERVER=time.xtracloud.net\nNTP_SERVER_2=europe.pool.ntp.org/g' $CFG
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done
fi

ui_print "***************************************************"
ui_print "*           You live in North America?            *"
ui_print "***************************************************"
ui_print "* [Vol Up = YES          |         Vol Down = NO] *"
ui_print "***************************************************"

if $VKSEL; then

ui_print "*        ->[Select North America Region]<-        *"
ui_print "***************************************************"

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG
	sed -i '/NTP_SERVER/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=north-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=0.north-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=1.north-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_5=2.north-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_6=3.north-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=north-america.pool.ntp.org$/NTP_SERVER=time.xtracloud.net\nNTP_SERVER_2=north-america.pool.ntp.org/g' $CFG
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done
fi

ui_print "***************************************************"
ui_print "*              You live in Oceania?               *"
ui_print "***************************************************"
ui_print "* [Vol Up = YES          |         Vol Down = NO] *"
ui_print "***************************************************"

if $VKSEL; then

ui_print "*           ->[Select Oceania Region]<-           *"
ui_print "***************************************************"

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG
	sed -i '/NTP_SERVER/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=oceania.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=0.oceania.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=1.oceania.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_5=2.oceania.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_6=3.oceania.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=oceania.pool.ntp.org$/NTP_SERVER=time.xtracloud.net\nNTP_SERVER_2=oceania.pool.ntp.org/g' $CFG
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done
fi

ui_print "***************************************************"
ui_print "*           You live in South America?            *"
ui_print "***************************************************"
ui_print "* [Vol Up = YES          |         Vol Down = NO] *"
ui_print "***************************************************"

if $VKSEL; then

ui_print "*        ->[Select South America Region]<-        *"
ui_print "***************************************************"


  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG
	sed -i '/NTP_SERVER/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=south-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=0.south-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=1.south-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_5=2.south-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_6=3.south-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=south-america.pool.ntp.org$/NTP_SERVER=time.xtracloud.net\nNTP_SERVER_2=south-america.pool.ntp.org/g' $CFG
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done
fi
fi
ui_print "***************************************************"
ui_print " "

	rm -rf $MODPATH/tools/*
	rm -rf /data/system/package_cache/*/*
	rm -rf /data/resource-cache/*
	rm -rf /cache/*
	find $MODPATH -empty -type d -delete
