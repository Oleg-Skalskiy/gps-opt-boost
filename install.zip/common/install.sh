
GPSCFG="$(find /system /vendor /system_ext /product /odm -type f -name "gps*.conf")"
mkdir -p $MODPATH/tools
cp -f $MODPATH/common/addon/External-Tools/tools/$ARCH32/* $MODPATH/tools/

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	cp_ch $ORIGDIR$GCFG $CFG
	sed -i 's/\t/  /g' $CFG
	sed -i 's/DEBUG_LEVEL = 1/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 2/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 3/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 4/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 5/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/SUPL_ES=0/SUPL_ES=1/g' $CFG
	sed -i 's/AGPS_CONFIG_INJECT = 0/AGPS_CONFIG_INJECT = 1/g' $CFG
	sed -i 's/CP_MTLR_ES=0/CP_MTLR_ES=1/g' $CFG
	sed -i 's/BUFFER_DIAG_LOGGING = 1/BUFFER_DIAG_LOGGING = 0/g' $CFG
	sed -i 's/USE_EMERGENCY_PDN_FOR_EMERGENCY_SUPL=0/USE_EMERGENCY_PDN_FOR_EMERGENCY_SUPL=1/g' $CFG
	sed -i '/ACCURACY_THRES=/d;s/^DEBUG_LEVEL = 0$/ACCURACY_THRES=0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/ENABLE_WIPER=/d;s/^DEBUG_LEVEL = 0$/ENABLE_WIPER=1\nDEBUG_LEVEL = 0/g' $CFG
	done

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i '/NTP_SERVER=/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=ru.pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2=/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_2=europe.pool.ntp.org\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3=/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_3=0.ru.pool.ntp.org\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4=/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_4=1.ru.pool.ntp.org\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5=/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_5=2.ru.pool.ntp.org\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6=/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_6=3.ru.pool.ntp.org\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_7=/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_7=ntp0.NL.net\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_8=/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_8=clock.isc.org\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_9=/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_9=ntp2.vniiftri.ru\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_10=/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_10=ntps1-1.cs.tu-berlin.de\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_11=/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_11=ntp.ix.ru\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=europe.pool.ntp.org$/NTP_SERVER=ru.pool.ntp.org\nNTP_SERVER_2=europe.pool.ntp.org/g' $CFG
	done

ui_print " "
  ui_print "***************************************************"
  ui_print "*  The NTP Server Russia is selected by default   *"
  ui_print "*  Would you like to choose a different server?   *"
  ui_print "***************************************************"
ui_print " "
sleep 1
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " "

if $VKSEL; then

ui_print " "
  ui_print "***************************************************"
  ui_print "*              You live in Africa?                *"
  ui_print "***************************************************"
ui_print " "
sleep 1
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " " 

if $VKSEL; then

ui_print " - Select Africa Region -"
ui_print " " 

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i '/NTP_SERVER=/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=africa.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=0.africa.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=1.africa.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_5=2.africa.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_6=3.africa.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_7=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_7=ntp0.NL.net\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_8=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_8=clock.isc.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_9=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_9=ntp2.vniiftri.ru\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_10=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_10=ntps1-1.cs.tu-berlin.de\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_11=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_11=ntp.ix.ru\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=africa.pool.ntp.org$/NTP_SERVER=pool.ntp.org\nNTP_SERVER_2=africa.pool.ntp.org/g' $CFG
	done
fi
ui_print " "
  ui_print "***************************************************"
  ui_print "*               You live in Asia?                 *"
  ui_print "***************************************************"
ui_print " "
sleep 1
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " " 

if $VKSEL; then

ui_print " - Select Asia Region -"
ui_print " " 

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i '/NTP_SERVER=/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=asia.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=0.asia.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=1.asia.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_5=2.asia.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_6=3.ru.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_7=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_7=ntp0.NL.net\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_8=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_8=clock.isc.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_9=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_9=ntp2.vniiftri.ru\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_10=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_10=ntps1-1.cs.tu-berlin.de\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_11=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_11=ntp.ix.ru\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=asia.pool.ntp.org$/NTP_SERVER=pool.ntp.org\nNTP_SERVER_2=asia.pool.ntp.org/g' $CFG
	done
fi
ui_print " "
  ui_print "***************************************************"
  ui_print "*              You live in Europe?                *"
  ui_print "***************************************************"
ui_print " "
sleep 1
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " " 

if $VKSEL; then

ui_print " - Select Europe Region -"
ui_print " " 

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i '/NTP_SERVER=/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=europe.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=0.europe.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=1.europe.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_5=2.europe.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_6=3.europe.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_7=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_7=ntp0.NL.net\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_8=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_8=clock.isc.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_9=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_9=ntp2.vniiftri.ru\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_10=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_10=ntps1-1.cs.tu-berlin.de\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_11=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_11=ntp.ix.ru\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=europe.pool.ntp.org$/NTP_SERVER=pool.ntp.org\nNTP_SERVER_2=europe.pool.ntp.org/g' $CFG
	done
fi
ui_print " "
  ui_print "***************************************************"
  ui_print "*           You live in North America?            *"
  ui_print "***************************************************"
ui_print " "
sleep 1
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " " 

if $VKSEL; then

ui_print " - Select North America Region -"
ui_print " " 

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i '/NTP_SERVER=/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=north-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=0.north-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=1.north-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_5=2.north-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_6=3.north-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_7=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_7=ntp0.NL.net\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_8=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_8=clock.isc.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_9=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_9=ntp2.vniiftri.ru\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_10=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_10=ntps1-1.cs.tu-berlin.de\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_11=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_11=ntp.ix.ru\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=north-america.pool.ntp.org$/NTP_SERVER=pool.ntp.org\nNTP_SERVER_2=north-america.pool.ntp.org/g' $CFG
	done
fi
ui_print " "
  ui_print "***************************************************"
  ui_print "*              You live in Oceania?                *"
  ui_print "***************************************************"
ui_print " "
sleep 1
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " " 

if $VKSEL; then

ui_print " - Select Oceania Region -"
ui_print " " 

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i '/NTP_SERVER=/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=oceania.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=0.oceania.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=1.oceania.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_5=2.oceania.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_6=3.oceania.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_7=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_7=ntp0.NL.net\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_8=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_8=clock.isc.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_9=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_9=ntp2.vniiftri.ru\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_10=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_10=ntps1-1.cs.tu-berlin.de\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_11=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_11=ntp.ix.ru\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=oceania.pool.ntp.org$/NTP_SERVER=pool.ntp.org\nNTP_SERVER_2=oceania.pool.ntp.org/g' $CFG
	done
fi
ui_print " "
  ui_print "***************************************************"
  ui_print "*           You live in South America?            *"
  ui_print "***************************************************"
ui_print " "
sleep 1
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " " 

if $VKSEL; then

ui_print " - Select South America Region -"
ui_print " " 

  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i '/NTP_SERVER=/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=south-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=0.south-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=1.south-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_5=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_5=2.south-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_6=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_6=3.south-america.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_7=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_7=ntp0.NL.net\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_8=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_8=clock.isc.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_9=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_9=ntp2.vniiftri.ru\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_10=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_10=ntps1-1.cs.tu-berlin.de\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_11=/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_11=ntp.ix.ru\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=south-america.pool.ntp.org$/NTP_SERVER=pool.ntp.org\nNTP_SERVER_2=south-america.pool.ntp.org/g' $CFG
	done
fi
fi

	rm -rf /data/system/*_cache/*
	rm -rf /data/vendor/*_cache/*
	rm -rf /data/misc/*_cache/*
	rm -rf /data/*-cache/*
	rm -rf /data/data/com.miui.yellowpage/*
	rm -rf /data/data/com.google.android.gms/app_dg_cache/*
	rm -rf /cache/*
	rm -rf /dalvik-cache/*
	rm -rf /data/cache/*
	rm -rf /data/dalvik-cache/*
	rm -rf /data/anr/*
	rm -rf /data/system/dropbox/*
	rm -rf /data/vendor/dropbox/*
	rm -rf /data/misc/dropbox/*
	rm -rf /data/app/preinstall_history/*
	rm -rf /data/tombstones/*
	rm -rf /data/system/tombstones/*
	rm -rf /data/vendor/tombstones/*
	rm -rf /data/misc/tombstones/*
	rm -rf /data/system_ce/0/recent_*/*
	rm -rf /data/system/trace/*
	rm -rf /data/vendor/trace/*
	rm -rf /data/misc/trace/*
	rm -rf /data/system/stats*/*
	rm -rf /data/vendor/stats*/*
	rm -rf /data/misc/stats*/*
	rm -rf /data/system/*stats/*
	rm -rf /data/vendor/*stats/*
	rm -rf /data/misc/*stats/*
	rm -rf /data/system/bootstat/*
	rm -rf /data/system/boottrace/*
	rm -rf /data/vendor/bootstat/*
	rm -rf /data/vendor/boottrace/*
	rm -rf /data/misc/bootstat/*
	rm -rf /data/misc/boottrace/*
	rm -rf /data/system/*_log/*
	rm -rf /data/vendor/*_log/*
	rm -rf /data/misc/*_log/*
	rm -rf /data/system/*_logs/*
	rm -rf /data/vendor/*_logs/*
	rm -rf /data/misc/*_logs/*
	rm -rf /data/system/*_logger/*
	rm -rf /data/vendor/*_logger/*
	rm -rf /data/misc/*_logger/*
